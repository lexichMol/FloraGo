package com.example.myapplication;

import static com.example.myapplication.NotificationReceiver.scheduleNotification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.TextView;

import com.allyants.notifyme.NotifyMe;

import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView = (TextView) findViewById(R.id.sss);




//        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//
//        String id = "my_channel_01";
//
//        CharSequence name = "name";
//
//        String description = "channel_description";
//
//        int importance = NotificationManager.IMPORTANCE_LOW;
//
//        NotificationChannel mChannel = new NotificationChannel(id, name,importance);
//
//        mChannel.setDescription(description);
//
//        mChannel.enableLights(true);
//        mChannel.setLightColor(Color.RED);
//
//        mChannel.enableVibration(true);
//        mChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
//
//        mNotificationManager.createNotificationChannel(mChannel);
//
//        int notifyID = 1;




//        Intent alarmIntent = new Intent(this, AlarmReceiver.class);
//        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, 0);
//
//        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
//
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTimeInMillis(System.currentTimeMillis());
//        calendar.set(Calendar.HOUR_OF_DAY, 10);
//        calendar.set(Calendar.MINUTE, 53);
//        calendar.set(Calendar.SECOND, 1);
//
//        manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
//                AlarmManager.INTERVAL_DAY, pendingIntent);





//        NotificationCompat.Builder mBuilder;
//        mBuilder = new NotificationCompat.Builder(getApplicationContext())
//                .setSmallIcon(R.mipmap.ic_launcher)
//                .setContentTitle("Title")
//                .setContentText("Text")
//                .setOngoing(true)
//                .setChannelId(id);
//        mNotificationManager.notify();

        Date currentTime = Calendar.getInstance().getTime();


        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar now = Calendar.getInstance();
                NotifyMe notifyMe = new NotifyMe.Builder(getApplicationContext())

                        .title("title")
                        .content("content")
                        .color(255, 0, 0, 255)//Color of notification header
                        .led_color(255, 255, 255, 255)//Color of LED when notification pops up
                        .time(now)//The time to popup notification
                        .addAction(new Intent(),"Dismiss", false)
                        .addAction(new Intent(),"done")
                        .large_icon(R.mipmap.ic_launcher_round)//Icon resource by ID
                        .build();




//                String CHANNEL_ID = "my_channel_01";
//
//                Notification notification = new Notification.Builder(MainActivity.this)
//                        .setContentTitle("New Message")
//                        .setContentText("You've received new messages.")
//                        .setSmallIcon(R.drawable.ic_launcher_foreground)
//                        .setChannelId(CHANNEL_ID)
//                        .build();
//
//                mNotificationManager.notify(2, notification);

//                int notifyID = 1;
//
//                String CHANNEL_ID = "my_channel_01";
//
//                Notification notification = new Notification.Builder(MainActivity.this)
//                        .setContentTitle("New Message")
//                        .setContentText("You've received new messages.")
//                        .setSmallIcon(R.drawable.ic_launcher_foreground)
//                        .setChannelId(CHANNEL_ID)
//                        .build();
//
//                mNotificationManager.notify(2, notification);




//                NotificationCompat.Builder builder =
//                        new NotificationCompat.Builder(MainActivity.this)
//                                .setSmallIcon(R.mipmap.ic_launcher)
//                                .setContentTitle("Title")
//                                .setContentText("Notification text");
//
//                Notification notification = builder.build();
//
//                NotificationManager notificationManager =
//                        (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//                notificationManager.notify(1, notification);
            }
        });




    }
    public void reminderNotification()
    {
        NotificationUtils _notificationUtils = new NotificationUtils(this);
        long _currentTime = System.currentTimeMillis();
        long tenSeconds = 1000 * 10;
        long _triggerReminder = _currentTime + tenSeconds; //triggers a reminder after 10 seconds.
        _notificationUtils.setReminder(_triggerReminder);
    }

}